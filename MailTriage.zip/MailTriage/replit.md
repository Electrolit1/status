# Overview

This is a Minecraft server monitoring application built with React frontend and Express backend. The application monitors a Minecraft server (neobox.lol) and provides real-time status updates, player activity tracking, and historical data visualization through an intuitive dashboard interface.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript and Vite build system
- **UI Library**: shadcn/ui components with Radix UI primitives for accessibility
- **Styling**: Tailwind CSS with custom Minecraft-themed color palette and dark mode support
- **State Management**: TanStack Query for server state management and caching
- **Routing**: Wouter for lightweight client-side routing
- **Real-time Updates**: WebSocket connection for live server status updates
- **Charts**: Recharts library for player activity visualization

## Backend Architecture
- **Framework**: Express.js with TypeScript
- **Real-time Communication**: WebSocket server using the 'ws' library for live updates
- **Minecraft Integration**: minecraft-server-util package for server status polling
- **Data Storage**: In-memory storage with interface for future database integration
- **Development Setup**: Vite middleware integration for hot module replacement

## Database Schema
- **ORM**: Drizzle ORM with PostgreSQL dialect configuration
- **Tables**: 
  - `server_status`: Current server state with player counts, response times, and version info
  - `status_history`: Historical tracking of server events, downtime, and player activity
- **Migration**: Drizzle Kit for schema management and migrations

## Key Design Patterns
- **Repository Pattern**: Storage abstraction with IStorage interface allowing multiple implementations
- **Real-time Architecture**: WebSocket server broadcasts status updates to connected clients
- **Component Architecture**: Reusable UI components with consistent theming and accessibility
- **Type Safety**: Comprehensive TypeScript coverage with Zod schemas for validation

# External Dependencies

## Core Technologies
- **Node.js Runtime**: ES modules with TypeScript compilation
- **React Ecosystem**: React 18, React Query, React Hook Form with Zod validation
- **Database**: PostgreSQL with Drizzle ORM and Neon serverless driver
- **Build Tools**: Vite with ESBuild for production bundling

## UI and Styling
- **Component Library**: Radix UI primitives for accessible components
- **Styling**: Tailwind CSS with PostCSS processing
- **Icons**: Lucide React icon library
- **Charts**: Recharts for data visualization
- **Fonts**: Google Fonts (Inter, Fira Code) for typography

## Server Monitoring
- **Minecraft Integration**: minecraft-server-util for server status checking
- **WebSocket**: ws library for real-time communication
- **Session Management**: connect-pg-simple for PostgreSQL session storage

## Development Tools
- **Replit Integration**: Vite plugins for runtime error overlay, cartographer, and dev banner
- **TypeScript**: Strict configuration with path mapping
- **Linting**: ESLint configuration (implied by project structure)