import { type ServerStatus, type StatusHistory, type InsertServerStatus, type InsertStatusHistory } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Server Status
  getServerStatus(serverAddress: string): Promise<ServerStatus | undefined>;
  updateServerStatus(serverAddress: string, status: InsertServerStatus): Promise<ServerStatus>;
  
  // Status History
  getStatusHistory(serverAddress: string, limit?: number): Promise<StatusHistory[]>;
  addStatusHistory(history: InsertStatusHistory): Promise<StatusHistory>;
  getPlayerActivityHistory(serverAddress: string, hours: number): Promise<StatusHistory[]>;
}

export class MemStorage implements IStorage {
  private serverStatuses: Map<string, ServerStatus>;
  private statusHistories: Map<string, StatusHistory[]>;

  constructor() {
    this.serverStatuses = new Map();
    this.statusHistories = new Map();
  }

  async getServerStatus(serverAddress: string): Promise<ServerStatus | undefined> {
    return this.serverStatuses.get(serverAddress);
  }

  async updateServerStatus(serverAddress: string, status: InsertServerStatus): Promise<ServerStatus> {
    const serverStatus: ServerStatus = {
      id: randomUUID(),
      ...status,
      version: status.version ?? null,
      motd: status.motd ?? null,
      currentPlayers: status.currentPlayers ?? null,
      maxPlayers: status.maxPlayers ?? null,
      responseTime: status.responseTime ?? null,
      lastChecked: new Date(),
    };
    this.serverStatuses.set(serverAddress, serverStatus);
    return serverStatus;
  }

  async getStatusHistory(serverAddress: string, limit: number = 50): Promise<StatusHistory[]> {
    const histories = this.statusHistories.get(serverAddress) || [];
    return histories
      .sort((a, b) => (b.timestamp?.getTime() || 0) - (a.timestamp?.getTime() || 0))
      .slice(0, limit);
  }

  async addStatusHistory(history: InsertStatusHistory): Promise<StatusHistory> {
    const statusHistory: StatusHistory = {
      id: randomUUID(),
      ...history,
      currentPlayers: history.currentPlayers ?? null,
      maxPlayers: history.maxPlayers ?? null,
      responseTime: history.responseTime ?? null,
      event: history.event ?? null,
      duration: history.duration ?? null,
      timestamp: new Date(),
    };

    const serverHistories = this.statusHistories.get(history.serverAddress) || [];
    serverHistories.push(statusHistory);
    this.statusHistories.set(history.serverAddress, serverHistories);

    return statusHistory;
  }

  async getPlayerActivityHistory(serverAddress: string, hours: number): Promise<StatusHistory[]> {
    const cutoffTime = new Date(Date.now() - hours * 60 * 60 * 1000);
    const histories = this.statusHistories.get(serverAddress) || [];
    
    return histories
      .filter(h => h.timestamp && h.timestamp >= cutoffTime)
      .sort((a, b) => (a.timestamp?.getTime() || 0) - (b.timestamp?.getTime() || 0));
  }
}

export const storage = new MemStorage();
