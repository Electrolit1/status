import { status } from 'minecraft-server-util';
import { storage } from '../storage';
import { WebSocket } from 'ws';

export interface MinecraftServerInfo {
  serverAddress: string;
  isOnline: boolean;
  currentPlayers: number;
  maxPlayers: number;
  responseTime: number;
  version?: string;
  motd?: string;
}

export class MinecraftMonitor {
  private serverAddress: string = 'neobox.lol';
  private port: number = 25565;
  private clients: Set<WebSocket> = new Set();
  private lastStatus: MinecraftServerInfo | null = null;

  constructor() {
    this.startMonitoring();
  }

  addClient(ws: WebSocket) {
    this.clients.add(ws);
    
    // Send current status to new client
    if (this.lastStatus) {
      this.sendToClient(ws, {
        type: 'status_update',
        data: this.lastStatus
      });
    }

    ws.on('close', () => {
      this.clients.delete(ws);
    });
  }

  private sendToClient(ws: WebSocket, message: any) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  }

  private broadcast(message: any) {
    this.clients.forEach(client => {
      this.sendToClient(client, message);
    });
  }

  private async checkServerStatus(): Promise<MinecraftServerInfo | null> {
    try {
      const startTime = Date.now();
      const result = await status(this.serverAddress, this.port, { timeout: 5000 });
      const responseTime = Date.now() - startTime;

      const serverInfo: MinecraftServerInfo = {
        serverAddress: this.serverAddress,
        isOnline: true,
        currentPlayers: result.players.online,
        maxPlayers: result.players.max,
        responseTime,
        version: result.version.name,
        motd: result.motd.clean || 'NeoBox Minecraft Server'
      };

      return serverInfo;
    } catch (error) {
      console.error('Failed to check server status:', error);
      return {
        serverAddress: this.serverAddress,
        isOnline: false,
        currentPlayers: 0,
        maxPlayers: 0,
        responseTime: 0,
        version: 'Unknown',
        motd: 'Server Offline'
      };
    }
  }

  private async processStatusUpdate(serverInfo: MinecraftServerInfo) {
    // Update current status
    await storage.updateServerStatus(this.serverAddress, {
      serverAddress: serverInfo.serverAddress,
      isOnline: serverInfo.isOnline,
      currentPlayers: serverInfo.currentPlayers,
      maxPlayers: serverInfo.maxPlayers,
      responseTime: serverInfo.responseTime,
      version: serverInfo.version,
      motd: serverInfo.motd
    });

    // Determine if we need to add a history event
    let event: string | undefined;
    let duration: number | undefined;

    if (this.lastStatus) {
      if (this.lastStatus.isOnline !== serverInfo.isOnline) {
        if (serverInfo.isOnline) {
          event = 'online';
          // Calculate downtime if we have previous offline status
          const histories = await storage.getStatusHistory(this.serverAddress, 10);
          const lastOfflineEvent = histories.find(h => h.event === 'offline');
          if (lastOfflineEvent && lastOfflineEvent.timestamp) {
            duration = Math.floor((Date.now() - lastOfflineEvent.timestamp.getTime()) / (1000 * 60));
          }
        } else {
          event = 'offline';
        }
      } else if (serverInfo.isOnline && serverInfo.currentPlayers > serverInfo.maxPlayers * 0.8) {
        // High load detection (80% capacity)
        event = 'high_load';
      }
    } else if (serverInfo.isOnline) {
      event = 'online';
    } else {
      event = 'offline';
    }

    // Add to history if there's an event
    if (event) {
      await storage.addStatusHistory({
        serverAddress: serverInfo.serverAddress,
        isOnline: serverInfo.isOnline,
        currentPlayers: serverInfo.currentPlayers,
        maxPlayers: serverInfo.maxPlayers,
        responseTime: serverInfo.responseTime,
        event,
        duration
      });
    }

    // Always add to history for player activity tracking
    await storage.addStatusHistory({
      serverAddress: serverInfo.serverAddress,
      isOnline: serverInfo.isOnline,
      currentPlayers: serverInfo.currentPlayers,
      maxPlayers: serverInfo.maxPlayers,
      responseTime: serverInfo.responseTime,
      event: 'activity'
    });

    this.lastStatus = serverInfo;

    // Broadcast to all connected clients
    this.broadcast({
      type: 'status_update',
      data: serverInfo
    });
  }

  private startMonitoring() {
    // Initial check
    this.checkServerStatus().then(status => {
      if (status) {
        this.processStatusUpdate(status);
      }
    });

    // Check every 2 minutes
    setInterval(async () => {
      const status = await this.checkServerStatus();
      if (status) {
        await this.processStatusUpdate(status);
      }
    }, 2 * 60 * 1000); // 2 minutes
  }

  async getLatestStatus(): Promise<MinecraftServerInfo | null> {
    if (this.lastStatus) {
      return this.lastStatus;
    }
    
    const status = await this.checkServerStatus();
    if (status) {
      await this.processStatusUpdate(status);
    }
    return status;
  }
}

export const minecraftMonitor = new MinecraftMonitor();
