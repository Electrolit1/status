import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { minecraftMonitor } from "./services/minecraft-monitor";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // WebSocket server for real-time updates
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', (ws: WebSocket) => {
    console.log('Client connected to WebSocket');
    minecraftMonitor.addClient(ws);

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        if (data.type === 'request_status') {
          const status = await minecraftMonitor.getLatestStatus();
          if (status) {
            ws.send(JSON.stringify({
              type: 'status_update',
              data: status
            }));
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('Client disconnected from WebSocket');
    });
  });

  // API Routes
  app.get('/api/server/status', async (req, res) => {
    try {
      const serverAddress = 'neobox.lol';
      const status = await storage.getServerStatus(serverAddress);
      
      if (!status) {
        // If no status found, trigger a fresh check
        const freshStatus = await minecraftMonitor.getLatestStatus();
        return res.json(freshStatus);
      }
      
      res.json(status);
    } catch (error) {
      console.error('Error fetching server status:', error);
      res.status(500).json({ message: 'Failed to fetch server status' });
    }
  });

  app.get('/api/server/history', async (req, res) => {
    try {
      const serverAddress = 'neobox.lol';
      const limit = parseInt(req.query.limit as string) || 50;
      const history = await storage.getStatusHistory(serverAddress, limit);
      res.json(history);
    } catch (error) {
      console.error('Error fetching status history:', error);
      res.status(500).json({ message: 'Failed to fetch status history' });
    }
  });

  app.get('/api/server/activity', async (req, res) => {
    try {
      const serverAddress = 'neobox.lol';
      const hours = parseInt(req.query.hours as string) || 24;
      const activity = await storage.getPlayerActivityHistory(serverAddress, hours);
      res.json(activity);
    } catch (error) {
      console.error('Error fetching player activity:', error);
      res.status(500).json({ message: 'Failed to fetch player activity' });
    }
  });

  app.post('/api/server/refresh', async (req, res) => {
    try {
      const status = await minecraftMonitor.getLatestStatus();
      res.json(status);
    } catch (error) {
      console.error('Error refreshing server status:', error);
      res.status(500).json({ message: 'Failed to refresh server status' });
    }
  });

  return httpServer;
}
