import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Filter } from "lucide-react";
import { useState } from "react";

interface StatusEvent {
  id: string;
  serverAddress: string;
  isOnline: boolean;
  currentPlayers: number;
  maxPlayers: number;
  responseTime?: number;
  timestamp: string;
  event?: string;
  duration?: number;
}

export function StatusHistory() {
  const [limit, setLimit] = useState("50");

  const { data: historyData, isLoading } = useQuery<StatusEvent[]>({
    queryKey: [`/api/server/history?limit=${parseInt(limit)}`],
    refetchInterval: 2 * 60 * 1000, // Refetch every 2 minutes
  });

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: false
    });
  };

  const getEventBadge = (event?: string, isOnline?: boolean) => {
    switch (event) {
      case 'online':
        return <Badge className="bg-primary/20 text-primary" data-testid="badge-online">ONLINE</Badge>;
      case 'offline':
        return <Badge className="bg-destructive/20 text-destructive" data-testid="badge-offline">OFFLINE</Badge>;
      case 'high_load':
        return <Badge className="bg-yellow-500/20 text-yellow-500" data-testid="badge-high-load">HIGH LOAD</Badge>;
      default:
        return isOnline ? 
          <Badge className="bg-primary/20 text-primary" data-testid="badge-activity-online">ACTIVE</Badge> : 
          <Badge className="bg-muted/20 text-muted-foreground" data-testid="badge-activity-offline">INACTIVE</Badge>;
    }
  };

  const getEventMessage = (event: StatusEvent) => {
    switch (event.event) {
      case 'online':
        return 'Server came back online';
      case 'offline':
        return 'Server went offline';
      case 'high_load':
        return 'High player activity detected';
      default:
        return `${event.currentPlayers} players online`;
    }
  };

  const getEventDetails = (event: StatusEvent) => {
    switch (event.event) {
      case 'online':
        return event.duration ? `Downtime: ${event.duration} minutes` : 'Server is now accessible';
      case 'offline':
        return 'Server became unreachable';
      case 'high_load':
        return `${event.currentPlayers}/${event.maxPlayers} players online (Peak activity)`;
      default:
        return event.responseTime ? `Response time: ${event.responseTime}ms` : '';
    }
  };

  return (
    <Card className="minecraft-border bg-card mb-8" data-testid="card-status-history">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle data-testid="title-status-history">Status History</CardTitle>
          <div className="flex items-center space-x-2">
            <Select value={limit} onValueChange={setLimit} data-testid="select-history-limit">
              <SelectTrigger className="w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="10">Last 10 events</SelectItem>
                <SelectItem value="25">Last 25 events</SelectItem>
                <SelectItem value="50">Last 50 events</SelectItem>
                <SelectItem value="100">Last 100 events</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="secondary" size="sm" data-testid="button-filter-history">
              <Filter className="mr-1 h-4 w-4" />
              Filter
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4 p-4 bg-muted/20 rounded-lg border border-border/50 animate-pulse" data-testid={`history-skeleton-${i}`}>
                <div className="w-3 h-3 bg-muted rounded-full"></div>
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-muted rounded w-3/4"></div>
                  <div className="h-3 bg-muted rounded w-1/2"></div>
                </div>
                <div className="w-20 h-6 bg-muted rounded"></div>
              </div>
            ))}
          </div>
        ) : historyData && historyData.length > 0 ? (
          <div className="space-y-4">
            {historyData.map((event) => (
              <div key={event.id} className="flex items-center space-x-4 p-4 bg-muted/20 rounded-lg border border-border/50" data-testid={`history-event-${event.id}`}>
                <div className={`w-3 h-3 rounded-full flex-shrink-0 ${event.isOnline ? 'bg-primary' : 'bg-destructive'}`} data-testid={`history-indicator-${event.id}`}></div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <p className="font-medium" data-testid={`history-message-${event.id}`}>{getEventMessage(event)}</p>
                    <span className="text-sm text-muted-foreground font-mono" data-testid={`history-timestamp-${event.id}`}>
                      {formatTimestamp(event.timestamp)}
                    </span>
                  </div>
                  {getEventDetails(event) && (
                    <p className="text-sm text-muted-foreground mt-1" data-testid={`history-details-${event.id}`}>
                      {getEventDetails(event)}
                    </p>
                  )}
                </div>
                <div data-testid={`history-badge-${event.id}`}>
                  {getEventBadge(event.event, event.isOnline)}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8" data-testid="history-no-data">
            <p className="text-muted-foreground">No status history available</p>
            <p className="text-sm text-muted-foreground mt-2">Server monitoring data will appear here once collected</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
