import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useState } from "react";

interface ActivityData {
  timestamp: string;
  currentPlayers: number;
  isOnline: boolean;
}

export function PlayerActivityChart() {
  const [timeRange, setTimeRange] = useState("24");

  const { data: activityData, isLoading } = useQuery<ActivityData[]>({
    queryKey: [`/api/server/activity?hours=${parseInt(timeRange)}`],
    refetchInterval: 2 * 60 * 1000, // Refetch every 2 minutes
  });

  // Process data for chart
  const processedData = activityData?.reduce((acc: any[], item, index) => {
    // Group data points by hour for better visualization
    const hour = new Date(item.timestamp).getHours();
    const existingEntry = acc.find(entry => entry.hour === hour);
    
    if (existingEntry) {
      existingEntry.players = Math.max(existingEntry.players, item.currentPlayers);
    } else {
      acc.push({
        hour,
        time: `${hour.toString().padStart(2, '0')}:00`,
        players: item.currentPlayers,
        isOnline: item.isOnline
      });
    }
    
    return acc;
  }, [])?.sort((a, b) => a.hour - b.hour) || [];

  return (
    <Card className="minecraft-border bg-card" data-testid="card-player-activity">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle data-testid="title-player-activity">Player Activity ({timeRange}h)</CardTitle>
          <Select value={timeRange} onValueChange={setTimeRange} data-testid="select-time-range">
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24">Last 24 hours</SelectItem>
              <SelectItem value="168">Last 7 days</SelectItem>
              <SelectItem value="720">Last 30 days</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-64 bg-muted/20 rounded-lg border border-border/50 flex items-center justify-center" data-testid="chart-loading">
            <p className="text-muted-foreground">Loading activity data...</p>
          </div>
        ) : processedData.length === 0 ? (
          <div className="h-64 bg-muted/20 rounded-lg border border-border/50 flex items-center justify-center" data-testid="chart-no-data">
            <p className="text-muted-foreground">No activity data available</p>
          </div>
        ) : (
          <div className="h-64" data-testid="chart-container">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={processedData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis 
                  dataKey="time" 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))"
                  fontSize={12}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px",
                    color: "hsl(var(--foreground))"
                  }}
                  formatter={(value: number) => [`${value} players`, "Online"]}
                  labelFormatter={(label) => `Time: ${label}`}
                />
                <Bar 
                  dataKey="players" 
                  fill="hsl(var(--primary))" 
                  opacity={0.8}
                  radius={[2, 2, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
        
        {/* Chart legend */}
        <div className="flex items-center justify-center mt-4 space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded"></div>
            <span className="text-sm text-muted-foreground">Online Players</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
