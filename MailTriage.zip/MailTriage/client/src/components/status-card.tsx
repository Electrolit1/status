import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";

interface StatusCardProps {
  title: string;
  value: string;
  subtitle: string;
  icon: React.ReactNode;
  status: "online" | "offline" | "warning" | "neutral";
  progress?: number;
  testId?: string;
}

export function StatusCard({ title, value, subtitle, icon, status, progress, testId }: StatusCardProps) {
  const getStatusClasses = () => {
    switch (status) {
      case "online":
        return "status-online";
      case "offline":
        return "status-offline";
      case "warning":
        return "status-warning";
      default:
        return "bg-card";
    }
  };

  const getStatusIndicator = () => {
    switch (status) {
      case "online":
        return <div className="w-4 h-4 bg-primary rounded-full animate-pulse" data-testid={`${testId}-indicator-online`}></div>;
      case "offline":
        return <div className="w-4 h-4 bg-destructive rounded-full" data-testid={`${testId}-indicator-offline`}></div>;
      case "warning":
        return <div className="w-4 h-4 bg-yellow-500 rounded-full animate-pulse" data-testid={`${testId}-indicator-warning`}></div>;
      default:
        return null;
    }
  };

  return (
    <Card className={`minecraft-border ${getStatusClasses()} p-6`} data-testid={testId}>
      <CardContent className="p-0">
        <div className="flex items-center justify-between mb-4">
          <div className="w-12 h-12 bg-primary/20 rounded-lg flex items-center justify-center">
            {icon}
          </div>
          {getStatusIndicator()}
        </div>
        <h3 className="text-lg font-semibold mb-2" data-testid={`${testId}-title`}>{title}</h3>
        <p className="text-3xl font-bold font-mono mb-1" data-testid={`${testId}-value`}>{value}</p>
        <p className="text-sm text-foreground/70" data-testid={`${testId}-subtitle`}>{subtitle}</p>
        {progress !== undefined && (
          <div className="mt-3">
            <Progress value={progress} className="h-2" data-testid={`${testId}-progress`} />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
