import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useWebSocket } from "@/hooks/use-websocket";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatusCard } from "@/components/status-card";
import { PlayerActivityChart } from "@/components/player-activity-chart";
import { StatusHistory } from "@/components/status-history";
import { Server, Users, Zap, HardDrive, Box, RefreshCw, Download, Activity } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

interface ServerStatus {
  serverAddress: string;
  isOnline: boolean;
  currentPlayers: number;
  maxPlayers: number;
  responseTime: number;
  version?: string;
  motd?: string;
  lastChecked?: string;
}

export default function Dashboard() {
  const queryClient = useQueryClient();
  const [lastCheck, setLastCheck] = useState<string>("Just now");
  const [nextCheckCountdown, setNextCheckCountdown] = useState<number>(120);

  // Fetch server status
  const { data: serverStatus, isLoading: statusLoading } = useQuery<ServerStatus>({
    queryKey: ['/api/server/status'],
    refetchInterval: 2 * 60 * 1000, // Refetch every 2 minutes
  });

  // WebSocket connection for real-time updates
  const { lastMessage, sendMessage } = useWebSocket('/ws');

  // Handle WebSocket messages
  useEffect(() => {
    if (lastMessage) {
      try {
        const data = JSON.parse(lastMessage);
        if (data.type === 'status_update') {
          queryClient.setQueryData(['/api/server/status'], data.data);
          setLastCheck("Just now");
          setNextCheckCountdown(120);
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error);
      }
    }
  }, [lastMessage, queryClient]);

  // Countdown timer for next check
  useEffect(() => {
    const interval = setInterval(() => {
      setNextCheckCountdown((prev) => {
        if (prev <= 1) {
          return 120; // Reset to 2 minutes
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  // Format countdown time
  const formatCountdown = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const handleRefreshStatus = async () => {
    try {
      await apiRequest('POST', '/api/server/refresh');
      queryClient.invalidateQueries({ queryKey: ['/api/server/status'] });
      setLastCheck("Just now");
      setNextCheckCountdown(120);
    } catch (error) {
      console.error('Failed to refresh status:', error);
    }
  };

  const handleTestConnection = () => {
    sendMessage(JSON.stringify({ type: 'request_status' }));
  };

  if (statusLoading && !serverStatus) {
    return (
      <div className="min-h-screen bg-background text-foreground flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-primary/20 rounded-lg flex items-center justify-center mb-4 mx-auto">
            <Box className="w-8 h-8 text-primary animate-pulse" />
          </div>
          <p className="text-lg font-medium">Loading server status...</p>
        </div>
      </div>
    );
  }

  const memoryUsage = serverStatus?.isOnline && serverStatus.maxPlayers > 0 ? 
    Math.floor(50 + (serverStatus.currentPlayers / serverStatus.maxPlayers) * 30) : 
    serverStatus?.isOnline ? 80 : 0;

  return (
    <div className="min-h-screen bg-background text-foreground">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-minecraft-grass border-2 border-minecraft-stone pixelated flex items-center justify-center">
                <Box className="text-foreground text-lg" />
              </div>
              <div>
                <h1 className="text-2xl font-bold font-mono text-foreground" data-testid="title-dashboard">NeoBox.lol</h1>
                <p className="text-sm text-muted-foreground">Server Monitor Dashboard</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm text-muted-foreground">Last Check</p>
                <p className="font-mono text-sm" data-testid="text-last-check">{lastCheck}</p>
              </div>
              <div className={`w-3 h-3 rounded-full pixel-pulse ${serverStatus?.isOnline ? 'bg-primary' : 'bg-destructive'}`} data-testid="status-indicator"></div>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        {/* Status Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatusCard
            title="Server Status"
            value={serverStatus?.isOnline ? "ONLINE" : "OFFLINE"}
            subtitle={serverStatus?.isOnline ? `Uptime: Active` : "Disconnected"}
            icon={<Server className="text-xl" />}
            status={serverStatus?.isOnline ? "online" : "offline"}
            testId="card-server-status"
          />

          <StatusCard
            title="Players Online"
            value={`${serverStatus?.currentPlayers || 0}`}
            subtitle={`Max: ${serverStatus?.maxPlayers || 0}`}
            icon={<Users className="text-xl" />}
            status="neutral"
            testId="card-players-online"
          />

          <StatusCard
            title="Response Time"
            value={serverStatus?.responseTime ? `${serverStatus.responseTime}ms` : "N/A"}
            subtitle={serverStatus?.responseTime && serverStatus.responseTime < 100 ? "Excellent" : 
                     serverStatus?.responseTime && serverStatus.responseTime < 200 ? "Good" : "Poor"}
            icon={<Zap className="text-xl" />}
            status="neutral"
            testId="card-response-time"
          />

          <StatusCard
            title="Memory Usage"
            value={`${memoryUsage}%`}
            subtitle="Server resources"
            icon={<HardDrive className="text-xl" />}
            status="neutral"
            testId="card-memory-usage"
            progress={memoryUsage}
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Player Activity Chart */}
          <div className="lg:col-span-2">
            <PlayerActivityChart />
          </div>

          {/* Quick Actions */}
          <Card className="minecraft-border bg-card" data-testid="card-quick-actions">
            <CardHeader>
              <CardTitle>Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={handleRefreshStatus}
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                data-testid="button-refresh-status"
              >
                <RefreshCw className="mr-2 h-4 w-4" />
                Refresh Status
              </Button>
              
              <Button 
                onClick={handleTestConnection}
                className="w-full bg-accent text-accent-foreground hover:bg-accent/90"
                data-testid="button-test-connection"
              >
                <Activity className="mr-2 h-4 w-4" />
                Test Connection
              </Button>
              
              <Button 
                variant="secondary"
                className="w-full"
                data-testid="button-download-report"
              >
                <Download className="mr-2 h-4 w-4" />
                Download Report
              </Button>

              {/* Server Info */}
              <div className="mt-8 space-y-3">
                <h4 className="font-semibold text-foreground">Server Information</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">IP Address:</span>
                    <span className="font-mono" data-testid="text-server-ip">neobox.lol</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Port:</span>
                    <span className="font-mono" data-testid="text-server-port">25565</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Version:</span>
                    <span className="font-mono" data-testid="text-server-version">{serverStatus?.version || "Unknown"}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">MOTD:</span>
                    <span className="text-xs" data-testid="text-server-motd">{serverStatus?.motd || "Welcome to NeoBox!"}</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Status History */}
        <StatusHistory />

        {/* Footer */}
        <footer className="border-t border-border pt-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <div className="w-8 h-8 bg-minecraft-grass border border-minecraft-stone pixelated flex items-center justify-center">
                <Box className="text-foreground text-sm" />
              </div>
              <div>
                <p className="font-semibold">NeoBox Server Monitor</p>
                <p className="text-sm text-muted-foreground">Powered by Minecraft Server Status API</p>
              </div>
            </div>
            <div className="flex items-center space-x-6 text-sm text-muted-foreground">
              <span>Auto-refresh: <strong className="text-accent">Every 2 minutes</strong></span>
              <span>•</span>
              <span>Next check in: <strong className="text-primary font-mono" data-testid="text-next-check">{formatCountdown(nextCheckCountdown)}</strong></span>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
}
