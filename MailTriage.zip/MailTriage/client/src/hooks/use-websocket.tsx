import { useEffect, useRef, useState, useCallback } from 'react';

interface UseWebSocketReturn {
  lastMessage: string | null;
  sendMessage: (message: string) => void;
  readyState: number;
  isConnected: boolean;
}

export function useWebSocket(url: string): UseWebSocketReturn {
  const [lastMessage, setLastMessage] = useState<string | null>(null);
  const [readyState, setReadyState] = useState<number>(WebSocket.CONNECTING);
  const ws = useRef<WebSocket | null>(null);

  const sendMessage = useCallback((message: string) => {
    if (ws.current && ws.current.readyState === WebSocket.OPEN) {
      ws.current.send(message);
    }
  }, []);

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}${url}`;
    
    const websocket = new WebSocket(wsUrl);
    ws.current = websocket;

    websocket.onopen = () => {
      console.log('WebSocket connected');
      setReadyState(WebSocket.OPEN);
    };

    websocket.onmessage = (event) => {
      setLastMessage(event.data);
    };

    websocket.onclose = () => {
      console.log('WebSocket disconnected');
      setReadyState(WebSocket.CLOSED);
    };

    websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
      setReadyState(WebSocket.CLOSED);
    };

    return () => {
      websocket.close();
    };
  }, [url]);

  const isConnected = readyState === WebSocket.OPEN;

  return {
    lastMessage,
    sendMessage,
    readyState,
    isConnected,
  };
}
