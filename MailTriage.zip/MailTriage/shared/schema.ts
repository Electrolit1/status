import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const serverStatus = pgTable("server_status", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  serverAddress: text("server_address").notNull(),
  isOnline: boolean("is_online").notNull(),
  currentPlayers: integer("current_players").default(0),
  maxPlayers: integer("max_players").default(0),
  responseTime: integer("response_time"), // in milliseconds
  version: text("version"),
  motd: text("motd"),
  lastChecked: timestamp("last_checked").defaultNow(),
});

export const statusHistory = pgTable("status_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  serverAddress: text("server_address").notNull(),
  isOnline: boolean("is_online").notNull(),
  currentPlayers: integer("current_players").default(0),
  maxPlayers: integer("max_players").default(0),
  responseTime: integer("response_time"),
  timestamp: timestamp("timestamp").defaultNow(),
  event: text("event"), // "online", "offline", "high_load", etc.
  duration: integer("duration"), // downtime duration in minutes
});

export const insertServerStatusSchema = createInsertSchema(serverStatus).omit({
  id: true,
  lastChecked: true,
});

export const insertStatusHistorySchema = createInsertSchema(statusHistory).omit({
  id: true,
  timestamp: true,
});

export type InsertServerStatus = z.infer<typeof insertServerStatusSchema>;
export type ServerStatus = typeof serverStatus.$inferSelect;
export type InsertStatusHistory = z.infer<typeof insertStatusHistorySchema>;
export type StatusHistory = typeof statusHistory.$inferSelect;
